#pragma once

enum class Colour { WHITE, BLACK };
enum class Type { PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING };